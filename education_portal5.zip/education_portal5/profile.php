<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['mob']==0)) {
  header('location:logout.php');
  } else{
    
?>
<html>
<head>
<title>The Education Portal</title>
<link rel="icon" href="images/logo13.jpg" type="image/x-icon">
<link  type="text/css" rel=stylesheet href=css/home_css.css />
</head>
<body>
<div class="head">
<a href="home.php"><div class="headleft"><img src="images/logo12.png" /></div></a>
<div class="headright">
<h1>The <span class="word1">E</span>ducation Portal</h1>
<div class="marque"><marquee scrollamount="10"><span class="word12">O</span>ne  Of  The  Best  Exam  <span class="word12	">P</span>reparation  Website</marquee></div>
<div class="profile">
	<div class="profilelogo"><img src="images/profile_logo.png" /></div>
	<div class="profilename"><p><?php
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from signup where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['fname'];
	echo " ";
	echo $result['lname'];
	}  ?></p></div>
</div>
</div>
<div class="menubar">
<div class="homebar"></div>
<ul>
<a href="home.php"><li>HOME</li></a>
<li><a href="test.php">Test</a></li>
<li><a href="preparation.html">Preparation</a></li>
<li><a href="about.html">Contact Us</a></li>
<li><a href="about.html">About Ranks</a></li>
</ul>
</div>
</div>
<div class="pagetop"></div>
<div class="pagebuttom">
<div class="profilebox">
<div class="profile_top">
<div class="profile_heading"><p>PROFILE</p></div>
</div>

<div class="profile_middle">
	<table>
		<tr><td width="250px">Name</td><td>-</td><td width="300px">
		<?php
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from signup where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['fname'];
	echo " ";
	echo $result['lname'];
	}  ?> </td></tr>

	<tr><td >Mobile Number</td><td>-</td><td ><?php
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from signup where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['mob'];
	}  ?></td></tr>

	<tr><td >Email Addess</td><td>-</td><td ><?php
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from signup where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['email'];
	}  ?></td></tr>


	<tr><td >Total Points</td><td>-</td><td ><?php
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from tpoints where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['tpoints'];
	}  ?></td></tr>


</table>
</div>

<div class="profile_bottom">
	<a href="logout.php"> <div class="logout_btn">
<p>Logout</p>
</div></a>
</div>

</div>
</div>

</div>
<div class="footer">
	<div class="foot1">
		<ul>
			<li>About Test	</li><p>|</p>
			<li>Contact Us	</li><p>|</p>
			<li>Terms And Conditions	</li><p>|</p>
			<li>Feedback	</li><p>|</p>
			<li>About Us</li>
		</ul>
	</div>
	<div class="foot3"></div>
	<div class="foot2">
		<h2>© 2018 by The Education Portal Team. All Rights Reserved | Copyright |</h2>
	</div>







</div>	
</body>
</html> <?php } ?>