<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['mob']==0)) {
  header('location:logout.php');
  } else{ 
?>

<html><head>
<title>The Education Portal</title>
<link rel="icon" href="images/logo13.jpg" type="image/x-icon">
<link  type="text/css" rel=stylesheet href=css/test.css />

</head>
<body>
<div class="head">
<a href="home.php"><div class="headleft"><img src="images/logo12.png" /></div></a>
<div class="headright">
<h1>The <span class="word1">E</span>ducation Portal</h1>
<div class="marque"><marquee scrollamount="10"><span class="word12">O</span>ne  Of  The  Best  Exam  <span class="word12	">P</span>reparation  Website</marquee></div>





<div class="profile">
	<a href="profile.php"><div class="profilelogo"><img src="images/profile_logo.png" /></div></a>
	<div class="profilename"><p>  <?php
	
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from signup where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['fname'];
	echo " ";
	echo $result['lname'];
	}  ?>  
</p></div>
	
</div>

</div>



<div class="menubar">
<div class="homebar"></div>
<ul>
<li><a href="home.php">HOME</a></li>
<li><a href="test.php">Test</a></li>
<li><a href="preparation.html">Preparation</a></li>
<li><a href="about.html">Contact Us</a></li>
<li><a href="about.html">About Ranks</a></li>
</ul>
</div>
</div>
<div class="pagetop"></div>
<div class="pagebuttom">
	<div class="middbox1">
<div class="imgbox">
<img src="images/bank.png"  id="img1"/>
<h3 id="img1txt" >Bank</h3>
</div>
<a href="gk.php"><div class="imgbox">
<img src="images/gk.png"  id="img1"/>
<h3 id="img1txt" >G.K.</h3>
</div></a>
<div class="imgbox">
<img src="images/aptitude.png"  id="img1"/>
<h3 id="img1txt" >Aptitude</h3>
</div>
<div class="imgbox">
<img src="images/placement.png"  id="img1"/>
<h3 id="img1txt" >Placement</h3>
</div>
<div class="imgbox">
<img src="images/interview.png"  id="img1"/>
<h3 id="img1txt" >Interview</h3>
</div>
<div class="imgbox">
<img src="images/reasoning.png"  id="img1"/>
<h3 id="img1txt" >Reasoning</h3>
</div>
<div class="imgbox">
<img src="images/online test.png"  id="img1"/>
<h3 id="img1txt" >Reasoning</h3>
</div>
<div class="imgbox">
<img src="images/english.png"  id="img1"/>
<h3 id="img1txt" >Reasoning</h3>
</div>

<div class="middbox12"><h1>Start Test</h1></div>
</div>
<div class="footer">
	<div class="foot1">
		<ul>
			<li>About Test	</li><p>|</p>
			<li>Contact Us	</li><p>|</p>
			<li>Terms And Conditions	</li><p>|</p>
			<li>Feedback	</li><p>|</p>
			<li>About Us</li>
		</ul>
	</div>
	<div class="foot3"></div>
	<div class="foot2">
		<h2>© 2018 by The Education Portal Team. All Rights Reserved | Copyright |</h2>
	</div>
</div>

</div>
</body></html><?php } ?>