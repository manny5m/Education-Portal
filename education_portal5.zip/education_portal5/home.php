<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['mob']==0)) {
  header('location:logout.php');
  } else{
    
?>
<html>
<head>
<title>The Education Portal</title>
<link rel="icon" href="images/logo13.jpg" type="image/x-icon">
<link  type="text/css" rel=stylesheet href=css/home_css.css />
</head>
<body>
<div class="head">
<a href="home.php"><div class="headleft"><img src="images/logo12.png" /></div></a>
<div class="headright">
<h1>The <span class="word1">E</span>ducation Portal</h1>
<div class="marque"><marquee scrollamount="10"><span class="word12">O</span>ne  Of  The  Best  Exam  <span class="word12	">P</span>reparation  Website</marquee></div>




<div class="profile">
	<a href="profile.php"><div class="profilelogo"><img src="images/profile_logo.png" /></div></a>
	<div class="profilename"><p><?php
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from signup where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['fname'];
	echo " ";
	echo $result['lname'];
	}  ?></p></div>
</div>



</div>
<div class="menubar">
<div class="homebar"></div>
<ul>
<a href="home.php"><li>HOME</li></a>
<li><a href="test.php">Test</a></li>
<li><a href="preparation.html">Preparation</a></li>
<li><a href="about.html">Contact Us</a></li>
<li><a href="about.html">About Ranks</a></li>
</ul>
</div>
</div>
<div class="pagetop"></div>
<div class="pagebuttom">
<div class="middbox1">
<div class="imgbox">
<img src="images/bank.png"  id="img1"/>
<h3 id="img1txt" >Bank</h3>
</div>
<a href="test.php"><div class="imgbox">
<img src="images/gk.png"  id="img1"/>
<h3 id="img1txt" >G.K.</h3>
</div></a>
<div class="imgbox">
<img src="images/aptitude.png"  id="img1"/>
<h3 id="img1txt" >Aptitude</h3>
</div>
<div class="imgbox">
<img src="images/placement.png"  id="img1"/>
<h3 id="img1txt" >Placement</h3>
</div>
<div class="imgbox">
<img src="images/interview.png"  id="img1"/>
<h3 id="img1txt" >Interview</h3>
</div>
<div class="imgbox">
<img src="images/reasoning.png"  id="img1"/>
<h3 id="img1txt" >Reasoning</h3>
</div>
<div class="middbox12"><h1>Show All Exams</h1></div>
</div>
<div class="middbox2">
	<h1 class="ranking">Ranking</h1>
	<div class="ranks"><span class="rank1">#1</span><span class="rank2">
	<img align="middle" src="images/gk.png" /></span> 
	<span class="rank3">Manish Vaishnav</span><span class="rank4">100 Points</span></div>
	<div class="ranks"><span class="rank1">#2</span><span class="rank2">
	<img align="middle" src="images/bank.png" /></span> 
	<span class="rank3">Arihant Mogra</span><span class="rank4">90 Points</span></div>
	<div class="ranks"><span class="rank1">#3</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Pawan Prajapat</span><span class="rank4">80 Points</span></div>
	<div class="ranks"><span class="rank1">#4</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Rahul Jain</span><span class="rank4">70 Points</span></div>
	<div class="ranks"><span class="rank1">#5</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Nitish Rana</span><span class="rank4">60 Points</span></div>
	<div class="ranks"><span class="rank1">#6</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Rohit Sharma</span><span class="rank4">50 Points</span></div>
	<div class="ranks"><span class="rank1">#7</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Umesh Yadav</span><span class="rank4">45 Points</span></div>
	<div class="ranks"><span class="rank1">#8</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Krunal Pandya</span><span class="rank4">40 Points</span></div>
	<div class="ranks"><span class="rank1">#9</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Ravindra Jadeja</span><span class="rank4">35 Points</span></div>
	<div class="ranks"><span class="rank1">#10</span><span class="rank2">
	<img src="images/login12.png" /></span> 
	<span class="rank3">Kedar Jadhav</span><span class="rank4">30 Points</span></div>
	<a href="ranks.php"> <h1 class="ranking1">Show More	</h1></a>
</div>
<div class="middown">

</div>
<div class="footer">
	<div class="foot1">
		<ul>
			<li>About Test	</li><p>|</p>
			<li>Contact Us	</li><p>|</p>
			<li>Terms And Conditions	</li><p>|</p>
			<li>Feedback	</li><p>|</p>
			<li>About Us</li>
		</ul>
	</div>
	<div class="foot3"></div>
	<div class="foot2">
		<h2>© 2018 by The Education Portal Team. All Rights Reserved | Copyright |</h2>
	</div>
</div>






</div>	
</body>
</html> <?php } ?>