<?php session_start();
include_once('includes/config.php');
?>
<html>
<head>
<script>
var count=0;
var attempt=0;
		function checkans(ans,gans,btn)
		{
			attempt++;
			document.form1.submit13.value=attempt;
			if(gans==ans)
			{
				count++;
				document.form1.submit12.value=count;
				btn.value="Correct";
				btn.disabled = true;
				
			}
			else
			{
				btn.value="InCorrect";
				btn.disabled = true;
			}
		}
		
		</script>
		
<title>The Education Portal</title>
<link rel="icon" href="images/logo13.jpg" type="image/x-icon">
<link  type="text/css" rel=stylesheet href=css/gk.css />
</head>
<body>
<div class="head">
<a href="index.html"><div class="headleft"><img src="images/logo12.png" /></div></a>
<div class="headright">
<h1>The <span class="word1">E</span>ducation Portal</h1>
<div class="marque"><marquee scrollamount="10"><span class="word12">O</span>ne  Of  The  Best  Exam  <span class="word12	">P</span>reparation  Website</marquee></div>

<a href="login.html"><div class="login">
<img src="images/newkey.png" /><img src="images/newkeyc.png" id="img19"/>
<h2><div class="word2">login</div> <div class="word3">/</div><div class="word4">Register	
</div></h2>
</div></a>	
</div>

<div class="menubar">
<div class="homebar"></div>
<ul>
<li><a href="index.html">HOME</a></li>
<li><a href="test.html">Test</a></li>
<li><a href="preparation.html">Preparation</a></li>
<li><a href="about.html">Contact Us</a></li>
<li><a href="about.html">About Ranks</a></li>
</ul>
</div>
</div>
<div class="pagetop"></div>
<div class="pagebuttom">
	<div id="quebox">
	<form name="form1" action="testres.php" method="post">
		<div id="quediv">
		<div id="queno"><h1>1</h1></div>
		<div id="que"><?php
		$sql= mysqli_query($con,"SELECT * FROM gkquestions WHERE qid='0001'");
		$row= mysqli_fetch_array($sql);
		if($row>0)
		{
		echo "<p>".$row['que']."</p><br>";
		echo "<table><tr>";
		echo "<td><input type='radio' id='radioid' name='result1'value='1'/></td>";
		echo "<td>".$row['option1']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result1'value='2'/></td>";
		echo "<td>".$row['option2']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result1'value='3'/></td>";
		echo "<td>".$row['option3']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result1'value='4'/></td>";
		echo "<td>".$row['option4']."</td></tr>";
		echo "</table>";
		$ans[0]=$row['correctans'];
		echo "<input type='button' name='corcheck' onclick='checkans($ans[0],document.form1.result1.value,document.form1.corcheck)' value='Done'/>";
		
		}?>
		</div>
		</div>
		<div id="quediv">
		<div id="queno"><h1>2</h1></div>
		<div id="que"><?php
		$sql= mysqli_query($con,"SELECT * FROM gkquestions WHERE qid='0002'");
		$row= mysqli_fetch_array($sql);
		if($row>0)
		{
		echo "<p>".$row['que']."</p><br>";
		echo "<table><tr>";
		echo "<td><input type='radio' id='radioid' name='result2' value='1'/></td>";
		echo "<td>".$row['option1']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result2' value='2'/></td>";
		echo "<td>".$row['option2']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result2' value='3'/></td>";
		echo "<td>".$row['option3']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result2' value='4'/></td>";
		echo "<td>".$row['option4']."</td></tr>";
		echo "</table>";
		$ans[1]=$row['correctans'];
		echo "<input type='button' name='corcheck1' onclick='checkans($ans[1],document.form1.result2.value,document.form1.corcheck1)' value='Done'/>";
		
		
		}?>
		</div>
		</div>
		<div id="quediv">
		<div id="queno"><h1>3</h1></div>
		<div id="que"><?php
		$sql= mysqli_query($con,"SELECT * FROM gkquestions WHERE qid='0003'");
		$row= mysqli_fetch_array($sql);
		if($row>0)
		{
		echo "<p>".$row['que']."</p><br>";
		echo "<table><tr>";
		echo "<td><input type='radio' id='radioid' name='result3' value='1'/></td>";
		echo "<td>".$row['option1']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result3' value='2'/></td>";
		echo "<td>".$row['option2']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result3' value='3'/></td>";
		echo "<td>".$row['option3']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result3' value='4'/></td>";
		echo "<td>".$row['option4']."</td></tr>";
		echo "</table>";
		$ans[2]=$row['correctans'];
		echo "<input type='button' name='corcheck2' onclick='checkans($ans[2],document.form1.result3.value,document.form1.corcheck2)' value='Done'/>";
		
		}?>
		</div>
		</div>
		<div id="quediv">
		<div id="queno"><h1>4</h1></div>
		<div id="que"><?php
		$sql= mysqli_query($con,"SELECT * FROM gkquestions WHERE qid='0004'");
		$row= mysqli_fetch_array($sql);
		if($row>0)
		{
		echo "<p>".$row['que']."</p><br>";
		echo "<table><tr>";
		echo "<td><input type='radio' id='radioid' name='result4' value='1'/></td>";
		echo "<td>".$row['option1']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result4' value='2'/></td>";
		echo "<td>".$row['option2']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result4' value='3'/></td>";
		echo "<td>".$row['option3']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result4' value='4'/></td>";
		echo "<td>".$row['option4']."</td></tr>";
		echo "</table>";
		$ans[3]=$row['correctans'];
		echo "<input type='button' name='corcheck3' onclick='checkans($ans[3],document.form1.result4.value,document.form1.corcheck3)' value='Done'/>";
		
		}?>
		</div>
		</div>
		<div id="quediv">
		<div id="queno"><h1>5</h1></div>
		<div id="que"><?php
		$sql= mysqli_query($con,"SELECT * FROM gkquestions WHERE qid='0005'");
		$row= mysqli_fetch_array($sql);
		if($row>0)
		{
		echo "<p>".$row['que']."</p><br>";
		echo "<table><tr>";
		echo "<td><input type='radio' id='radioid' name='result5' value='1'/></td>";
		echo "<td>".$row['option1']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result5'value='2'/></td>";
		echo "<td>".$row['option2']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result5'value='3'/></td>";
		echo "<td>".$row['option3']."</td></tr>";
		echo "<tr>";
		echo "<td><input type='radio' id='radioid' name='result5'value='4'/></td>";
		echo "<td>".$row['option4']."</td></tr>";
		echo "</table>";
		$ans[4]=$row['correctans'];
		echo "<input type='button' name='corcheck4' onclick='checkans($ans[4],document.form1.result5.value,document.form1.corcheck4)' value='Done'/>";
		
		}?>
		</div></div>
		<div id="submitres">
		<input type="submit" id="subres" name="submit11"  value="Result"/>
		<input type="textbox" id="subres1" name="submit12"  value="Counter"/>
		<input type="textbox" id="subres1" name="submit13"  value="Attempt"/>
		</div>
		
	</form>	
	</div>
</div><br><br><br><br><br>
<div class="footer">
	<div class="foot1">
		<ul>
			<li>About Test	</li><p>|</p>
			<li>Contact Us	</li><p>|</p>
			<li>Terms And Conditions	</li><p>|</p>
			<li>Feedback	</li><p>|</p>
			<li>About Us</li>
		</ul>
	</div>
	<div class="foot3"></div>
	<div class="foot2">
		<h2>© 2018 by The Education Portal Team. All Rights Reserved | Copyright |</h2>
	</div>
</div>

</div>
</body></html>