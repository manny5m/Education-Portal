<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['mob']==0)) {
  header('location:logout.php');
  } else{
?>    



<html>
<head>
<title>The Education Portal</title>
<link rel="icon" href="images/logo13.jpg" type="image/x-icon">
<link  type="text/css" rel=stylesheet href=gkres.css />
</head>
<body>
<div class="head">
<a href="home.php"><div class="headleft"><img src="images/logo12.png" /></div></a>
<div class="headright">
<h1>The <span class="word1">E</span>ducation Portal</h1>
<div class="marque"><marquee scrollamount="10"><span class="word12">O</span>ne  Of  The  Best  Exam  <span class="word12	">P</span>reparation  Website</marquee></div>






<div class="profile">
	<a href="profile.php"><div class="profilelogo"><img src="images/profile_logo.png" /></div></a>
	<div class="profilename"><p><?php
	$userid=$_SESSION['mob'];
	$query=mysqli_query($con,"select * from signup where mob='$userid'");
	while($result=mysqli_fetch_array($query))
	{
	echo $result['fname'];
	echo " ";
	echo $result['lname'];
	}  ?></p></div>
</div>




</div>


<div class="menubar">
<div class="homebar"></div>
<ul>
<li><a href="index.html">HOME</a></li>
<li><a href="test.html">Test</a></li>
<li><a href="preparation.html">Preparation</a></li>
<li><a href="about.html">Contact Us</a></li>
<li><a href="about.html">About Ranks</a></li>
</ul>
</div>
</div>
<div class="pagetop"></div>
<div class="pagebuttom">
<div id="quebox">
	<div id="divres">
	<h1>Gk Paper Result</h1><br>
	<h1>Student Name - Manish Vaishnav</h1>
		<table><tr>
		<td>Total No. Questions</td>
		<td>5</td></tr>
		<tr><td>Questions Attemped</td><?php
		$attempt=$_REQUEST["submit13"];
		$count=$_REQUEST["submit12"];
		$tpoints = $count*10;

		$get=$attempt - $count;
		echo "<td>".$attempt."</td></tr>";
		echo "<tr><td>Correct Answer</td> <td>".$count."</td></tr>";
		echo"<tr><td>InCorrect Answer</td><td>".$get."</td></tr>";
		echo"<tr><td>Total Points</td><td>". $tpoints ."</td>";
		
		$mob = $_SESSION['mob'];

		$sql=mysqli_query($con,"SELECT mob,tpoints from tpoints where mob='$mob'");
		$getsql=mysqli_fetch_array($sql);
		$ctpoints = $getsql['tpoints'] + $tpoints;

		$row=mysqli_num_rows($sql);
	
	if($row>0)
	{
		$msg=mysqli_query($con,"UPDATE tpoints SET tpoints='$ctpoints' WHERE mob = '$mob'");

	}
	?></tr></table>
	</div>
</div>
</div>

<div class="footer">
	<div class="foot1">
		<ul>
			<li>About Test	</li><p>|</p>
			<li>Contact Us	</li><p>|</p>
			<li>Terms And Conditions	</li><p>|</p>
			<li>Feedback	</li><p>|</p>
			<li>About Us</li>
		</ul>
	</div>
	<div class="foot3"></div>
	<div class="foot2">
		<h2>© 2018 by The Education Portal Team. All Rights Reserved | Copyright |</h2>
	</div>
</div>


</div></body></html>
<?php } ?>
