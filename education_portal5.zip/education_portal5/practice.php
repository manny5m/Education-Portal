<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['mob']==0)) {
  header('location:logout.php');
  } else{

	$allpoints = mysqli_query($con,"SELECT mob,tpoints from tpoints ORDER BY tpoints DESC");
	// $ctpoints = mysqli_query($con,"SELECT COUNT(tpoint) as count_tpoints FROM tpoints");

	// echo "$allpoints('mob',tpoints')";         , MYSQLI_ASSOC) !== false
	$i =0;
	$k = array();
	//echo "$k[0]";
	//for($b=0 $b<$ctpoints $b++){}

	//for( $i=1; $result=mysqli_fetch_array($allpoints)<10; $i++)	
	//{	
	//	$k[$i] = array_push($result['tpoints']) ;
		
	//}
	while($result=mysqli_fetch_array($allpoints))
	{
	$t = $result['tpoints'];
	$k[$i] = array_push(var_dump($t));
	$i++ ;

	}
	echo "$k[0]";
}
?>    