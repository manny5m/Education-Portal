<?php
session_start();
include_once('includes/config.php');
if(isset($_POST['login']))
{
$userphone=$_POST['txt1'];
$pass=$_POST['txt2'];
$sql= mysqli_query($con,"SELECT mob,pass FROM signup WHERE mob='$userphone' and pass='$pass'");
$num= mysqli_fetch_array($sql);
if($num>0)
{
$_SESSION['mob']=$num['mob'];

header("location:home.php");
}else{
	echo "<script> alert('Invalid Mobile or Password')</script>";
} 
}
?>
<html>
<head>
<title>Login Here</title>
<link rel="icon" href="images/logo13.jpg" type="image/x-icon">


<link  type="text/css" rel=stylesheet href=css/login.css />
</head>
<body>

<div class="head">
<a href="index.html"><div class="headleft"><img src="images/logo12.png" /></div></a>
<div class="headright">
<h1>The <span class="word1">E</span>ducation Portal</h1>
<div class="marque"><marquee scrollamount="17"><span class="word12">O</span>ne  Of  The  Best  Exam  <span class="word12	">P</span>reparation  Website</marquee></div>
<div class="loginload">
<h3>Loging in...</h3>
<span></span>
<span></span>
<span></span>
<span></span>
<span></span>
</div>
</div>

<div class="menubar">
<div id="homebar"></div>
<ul>
<li class="homemenu"><a href="index.html" >HOME</a></li>
<li>Test</li>
<li>Preparation</li>
<li><a href="about.html">Contact Us</a></li>
<li><a href="about.html">About Ranks</a></li>
</ul>
</div>
</div>
<div class="pagetop"></div>
<div class="pagebuttom1">
	
		<div id="fulllog" onclick="logopen()">
		<div id="logpage" >
			<h1>Login Here</h1>
			
			<form name="login" id="logform" onsubmit="return validsign()" method="post" >
			<h2>Phone Number<span id="starhide1">*</span></h2>
			<input type="text" name="txt1" id="txtbox1" placeholder="Enter Phone Number"/>
			<br><br>
			<h2>Password<span id="starhide2">*</span></h2>
			<input type="password" name="txt2" id="txtbox2" placeholder="Enter Password..."/>
			<p>Forget Password?</p>
			<div class="overit1">
					<p id="hidesign3">Please Fill All Field</p>
					<p id="hidesign4">Password Not Match</p>
					</div>
			<a href="signup.php"><h3>SignUp</h3></a>
			
			<input type="submit" id="logbtn" name="login" value="LOGIN" onblur="logblurfocus()" onfocus="onbtnfocus()"/>
			</form>	
		</div>
		</div>
		
	
	<div class="gap"></div>
	<div class="footer">
	<div class="foot1">
		<ul>
			<li>About Test	</li><p>|</p>
			<li>Contact Us	</li><p>|</p>
			<li>Terms And Conditions	</li><p>|</p>
			<li>Feedback	</li><p>|</p>
			<li>About Us</li>
		</ul>
	</div>
	<div class="foot3"></div>
	<div class="foot2">
		<h2>© 2018 by The Education Portal Team. All Rights Reserved | Copyright |</h2>
	</div>
</div>

</div>


<script>
window.onload = function() {
    document.getElementById("txtbox").focus();
};
	
	function validsign()
	{
		var a=document.login.txt1.value;
		var b=document.login.txt2.value;
		if(a=="")
		{
			document.getElementById("txtbox1").style.border="1px solid red";
			document.getElementById("starhide1").style.visibility="visible";
		}
		if(b=="")
		{
			document.getElementById("txtbox2").style.border="1px solid red";
			document.getElementById("starhide2").style.visibility="visible";
		}		
		
		if(a=="" || b=="")
		{
			document.getElementById("hidesign3").style.visibility="visible";
			return false;
		}
		
	}
		function logblurfocus()
	{
		document.getElementById("txtbox").focus();
		document.getElementById("logbtn").style.backgroundColor="#2f4f4f";
		document.getElementById("logbtn").style.boxShadow="1px 1px 5px 1px #2f4f4f";
	}
	function signblurfocus()
	{
		document.getElementById("signbtn").style.backgroundColor="#2f4f4f";
		document.getElementById("signbtn").style.boxShadow="1px 1px 5px 1px #2f4f4f";
	}
	
	function onbtnfocus()
	{
		document.getElementById("logbtn").style.backgroundColor="#ee3b3b";
		document.getElementById("logbtn").style.boxShadow="1px 1px 10px 2px #ee3b3b";	
	}
	function onbtnfocus1()
	{
		document.getElementById("signbtn").style.backgroundColor="#ee3b3b";
		document.getElementById("signbtn").style.boxShadow="1px 1px 10px 2px #ee3b3b";	
	}
</script>
</body></html>