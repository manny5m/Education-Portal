<html>
<head>
<title>Login Here</title>
<link rel="icon" href="images/logo13.jpg" type="image/x-icon">


<link  type="text/css" rel=stylesheet href=css/login.css />
</head>
<body>

<div class="head">
<a href="index.html"><div class="headleft"><img src="images/logo12.png" /></div></a>
<div class="headright">
<h1>The <span class="word1">E</span>ducation Portal</h1>
<div class="marque"><marquee scrollamount="17"><span class="word12">O</span>ne  Of  The  Best  Exam  <span class="word12	">P</span>reparation  Website</marquee></div>
<div class="loginload">
<h3>Loging in...</h3>
<span></span>
<span></span>
<span></span>
<span></span>
<span></span>
</div>
</div>

<div class="menubar">
<div id="homebar"></div>
<ul>
<li class="homemenu"><a href="index.html" >HOME</a></li>
<li>Test</li>
<li>Preparation</li>
<li><a href="about.html">Contact Us</a></li>
<li><a href="about.html">About Ranks</a></li>
</ul>
</div>
</div>
<div class="pagetop"></div>
<div class="pagebuttom1">


<?php
session_start();
$con=mysqli_connect("localhost","root","","eduportal");
if(!$con)
{
die("server not connected");
}
if(isset($_POST['login']))
{
$pass=$_POST['txt2'];
$userphone=$_POST['txt1'];
$sql= mysqli_query($con,"SELECT mob,pass FROM signup WHERE mob='$userphone' and pass='$pass'");
$num= mysqli_fetch_array($sql);

echo "$num";
/* if($sql>0)
{
$_SESSION['mob']=$num['mob'];
$_SESSION['pass']=$num['pass'];
// header("location:index.html");
}else{
	echo "<script> alert('Invalid Mobile or Password')</script>";
} */
 }
	
	?>
	</div>
	</body></html>