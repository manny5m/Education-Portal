<?php
$con=mysqlI_connect("localhost","root","","eduportal");
if(!$con){
	echo ("server not connected");}
	
	//$query="INSERT INTO 'eduportal','signup' VALUES('".$_REQUEST["txt11"]."','".$_REQUEST["txt12"]."',
			//".$_REQUEST["txt13"].",'".$_REQUEST["txt14"]."','".$_REQUEST["txt15"]."')";
	$fname = $_POST['txt11'];
	$lname = $_POST['txt12'];
	$email = $_POST['txt13'];
	$mob = $_POST['txt14'];
	$pass = $_POST['txt15'];
	$sql=mysqli_query($con,"SELECT mob from signup where mob='$mob'");
	$row=mysqli_num_rows($sql);
if($row>0)
{
    echo "<script>Document.getElementbyId('hidesign3').innerHTML='Mobile Number already exist with another account. Please try with other Mobile Number');</script>";
} else{
    $msg=mysqli_query($con,"INSERT INTO signup(fname,lname,email,mob,pass) values('$fname','$lname','$email','$mob','$pass')");

	if(($sql) == true)
	{
		$re="location:login.php";
		echo header($re);
	}
	else{
		echo "ERROR";
	}
};
?>
